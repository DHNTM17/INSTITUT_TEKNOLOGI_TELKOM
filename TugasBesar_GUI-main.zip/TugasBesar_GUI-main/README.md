[![fHPiDG.png](https://iili.io/fHPiDG.png)](https://freeimage.host/i/fHPiDG)

# Anggota Kelompok :
| NAMA | NIM | KELAS
|--|--|--|
| IRSYAD ZULKIFAR  | 19104040| 03 SE B
| ALDHAN TRI MAULANA  | 19104059 | 03 SE B
| NIKE PRASETYO | 19104068 | 03 SE B
# Requirements File
Jika inggin menjalankan program ini di python cmd harap install beberapa nama di bawah ini 
Berikut Nama Installanya : 

pip install Translator

pip install pandas

pip install PyQt5

pip install googletrans

pip install language*

# Data Base :
![enter image description here](https://i.ibb.co/Z2nq8LL/db.jpg)
# Demo Program :

![fH4oRs.gif](https://s6.gifyu.com/images/NEWd03abb72ab199145.gif)
# PyQT5 Desain:
![enter image description here](https://i.ibb.co/JQVJ41N/Screenshot-4.png)

